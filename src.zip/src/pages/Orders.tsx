import React from 'react';

const Orders = () => {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-3xl font-bold">Orders Page</h1>
    </div>
  );
};

export default Orders;
